﻿using BKTC;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace TKTDTT.Services
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class Webservices : System.Web.Services.WebService
    {
        [WebMethod]
        public Result GetData(string keySearch, int countNumber, int start = 0)
        {
            return JsonConvert.SerializeObject(Convertor.LoadJsonByAPI("http://beta.loga.vn:8983/solr/DataTKTDTT/select?fq=title:" + keySearch + "&fq=content:" + keySearch + "&q=*:*&start=" + start + "&rows=" + countNumber)).ToResultOk();
        }
        [WebMethod]
        public Result GetContent(string id)
        {
            return JsonConvert.SerializeObject(Convertor.LoadJsonByAPI("http://beta.loga.vn:8983/solr/DataTKTDTT/select?q=id:" + id)).ToResultOk();
        }
        [WebMethod]
        public Result GetAllTitle()
        {
            return JsonConvert.SerializeObject(Convertor.LoadJsonByAPI("http://beta.loga.vn:8983/solr/DataTKTDTT/select?fl=title&q=*:*&rows=10000")).ToResultOk();
        }
    }
}
